import Avatar1 from 'assets/images/avatars/avatar1.png';
import Avatar2 from 'assets/images/avatars/avatar2.png';
import Avatar3 from 'assets/images/avatars/avatar3.png';
import Avatar4 from 'assets/images/avatars/avatar4.png';
import Avatar5 from 'assets/images/avatars/avatar5.png';
import Avatar6 from 'assets/images/avatars/avatar6.png';
import Avatar7 from 'assets/images/avatars/avatar7.png';
import Avatar8 from 'assets/images/avatars/avatar8.png';
import Thumb1 from 'assets/images/thumbs/thumb1.png';
import Thumb2 from 'assets/images/thumbs/thumb2.png';
import Thumb3 from 'assets/images/thumbs/thumb3.png';
import Thumb4 from 'assets/images/thumbs/thumb4.png';
import Thumb5 from 'assets/images/thumbs/thumb5.png';
import Thumb6 from 'assets/images/thumbs/thumb6.png';
import Thumb7 from 'assets/images/thumbs/thumb7.png';
import Thumb8 from 'assets/images/thumbs/thumb8.png';

export {
  Avatar1,
  Avatar2,
  Avatar3,
  Avatar4,
  Avatar5,
  Avatar6,
  Avatar7,
  Avatar8,
  Thumb1,
  Thumb2,
  Thumb3,
  Thumb4,
  Thumb5,
  Thumb6,
  Thumb7,
  Thumb8,
};
